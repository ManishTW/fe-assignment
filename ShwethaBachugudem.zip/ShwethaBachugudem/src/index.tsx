import React from 'react';
import ReactDOM from 'react-dom';
import './index.css';
import App from './App';
import * as serviceWorker from './serviceWorker';
import { Provider } from 'react-redux'
import store from './store'
import { Route, BrowserRouter } from 'react-router-dom';
import Cart from "./components/cart/Cart";
import BookDetails from "./components/bookDetails/BookDetails";
import NavBar from "./components/navbar/NavBar";
import Orders from "./components/orders/Orders";
ReactDOM.render(
    <BrowserRouter >
  <React.StrictMode>
      <Provider store={store}>
          <NavBar/>
          <Route  exact path = "/" component = {App}/>
          <Route path = "/cart" component = {Cart}/>
          <Route path = "/details" component = {BookDetails}/>
          <Route path = "/orders" component = {Orders}/>
      </Provider>
  </React.StrictMode>
    </BrowserRouter>,
  document.getElementById('root')
);

// If you want your app to work offline and load faster, you can change
// unregister() to register() below. Note this comes with some pitfalls.
// Learn more about service workers: https://bit.ly/CRA-PWA
serviceWorker.unregister();
