import React from 'react';
import {Link} from "react-router-dom";
import './navbar.scss'

class NavBar extends React.Component {
    render() {
       return <div className='nav-bar'>
           <span className='header'>Ecommerce site</span>
           <div className='links'>
               <Link className='link' to='/'>Home |</Link>
               <Link className='link' to='/orders'>My Orders |</Link>
               <Link className='link' to='/cart'>Cart</Link>
           </div>

       </div>

    }
}
export default NavBar;
