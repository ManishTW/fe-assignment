import React from 'react';
import logo from './logo.svg';
import {fetchBooks, addToCart, showBook} from '../actions'
import { connect } from 'react-redux';
import {action} from "../../store";
import './book-details.scss'
import { Route } from 'react-router-dom'


interface MyState {
    // books: string
}
interface Book {
    title : string,
    id: number
}
interface MyProps {
    book: Book
}

class BookDetails extends React.Component<MyProps,MyState> {
    render() {
        const {book} = this.props;
        return <div className='book-details'>
            <div className= 'image'></div>
            <div className='book'>
                <div className='details'>
                    <div className= 'title'>{book.title}</div>
                    <div className= 'author'>{book.title}</div>
                    <div className= 'desciption'>{book.title}</div>
                    <Route render={({ history}) => (
                        <button className= 'buy-now' onClick={() => this.buyBook(book, history)}>Buy Now</button>
                    )} />
                    <Route render={({ history}) => (
                        <button className= 'buy-now' onClick={() => this.addCart(book, history)}> Add to Cart</button>
                    )} />
                </div>
                <div className='book-description'>{book.title}</div>
            </div>
        </div>

    }

    private buyBook(book: Book, history:any) {
        action(addToCart(book));
        history.push('/cart');
    }
    private addCart(book: Book, history:any) {
        action(addToCart(book));
        history.push('/');
    }
}
const mapStateToProps = (state:any) => ({
    book: state.currentBook
});
const mapDispatchToProps = {
    addToCart: addToCart
};
export default connect(mapStateToProps, mapDispatchToProps)(BookDetails);
