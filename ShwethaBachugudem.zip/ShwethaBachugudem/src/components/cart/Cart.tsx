import React from 'react';
import { connect} from "react-redux";
import BookTile from "../bookTile/BookTile";
import { buyBooks } from '../actions';
import {action} from "../../store";
import {Route} from "react-router";
import './cart.scss'

interface Book {
    title : string,
    id: number
}
interface CartProps {
    cart: Book[]
}

class Cart extends React.Component <CartProps>{
    render() {
        const {cart} = this.props;
        let price = 0;
        return <div className='cart'>
            <div className='billing-address'>
                <div className='ba-element'>
                    <div className="street">street</div>
                    <input />
                </div>
                <div className='ba-element'>
                    <div>pin</div>
                    <input className= 'pin'/>
                </div>
                <div className='ba-element'>
                    <div>city</div>
                    <input className= 'city'/>
                </div>
                <button className='submit'>Submit</button>
            </div>
            <div className= 'shopping-bag'>
                <div className='cart-details'>
                    {cart && cart.length > 0 && cart.map((book) => {
                        price = price+book.id;
                       return <div className='bag'>
                           <div className='title'> BOOK TITLE : </div>
                           <div> {book.title} </div>
                       </div>})
                    }
                </div>
                <div className='payment-info'>
                    <div className='wrapper'><div className='label'>Price</div><div className='price'>{price*2}</div></div>
                    <div className='wrapper'><div className='label'>Tax</div><div className='tax'>{price/5}</div></div>
                    <div className='wrapper'><div className='label'>Shipping charges</div><div className='shipping'>{price/10}</div></div>
                    <div className='wrapper'><div className='label'>Total Amount</div><div className='total'>{price*2  + price/5 + price/10}</div></div>
                    <Route render={({ history}) => (
                        <button onClick={() => {this.buyBooks(history);}}> checkout </button>
                    )} />
                    <Route render={({ history}) => (
                        <button onClick={() => {history.push('/')}}>cancel</button>
                    )} />
                </div>
            </div>

        </div>
    }

    private buyBooks(history: any) {
        history.push('/orders')
        action(buyBooks())
    }
}
const mapStateToProps = (state: any) => ({
    cart: state.cart
});
export default connect(mapStateToProps, null)(Cart);
