import React from 'react';
import {connect} from "react-redux";
import './orders.scss'

interface Book {
    title : string,
    id: number
}
interface CartProps {
    books: Book[]
}
class Orders extends React.Component<CartProps>{
    render() {
        const {books} = this.props;
        return <div> {books && books.length > 0 && books.map((book) => {
            return <div className='bag'>
                <div className='book'>
                    <div className= 'image'></div>
                    <div className='details'>
                        <div className='title'> {book.title} </div>
                        <div className='attribute'> Author : {book.title} </div>
                        <div className='attribute'> Price : {book.title} </div>
                    </div>

                </div>
            </div>
        })

        }</div>
    }
}
const mapStateToProps = (state:any) => ({
    books: state.boughtBooks
});
export default connect(mapStateToProps, null)(Orders);
