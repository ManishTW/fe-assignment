interface Book {
    title : string,
    id: number
}
export const addToCart = (book: Book) => {
    return ({
        "type": 'ADD_TO_CART', book
    });
};

export const showBook = (book: Book) => {
    return ({
        "type": 'SHOW_BOOK', book
    });
};
export const fetchBooks = () => {
    return({
        "type": 'FETCH_BOOKS',
    });
};
export const buyBooks = () => {
    return ({
        "type": 'BUY_BOOK'
    })
};

