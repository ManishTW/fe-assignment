import React from 'react';
import logo from './logo.svg';
import { fetchBooks, addToCart, showBook } from '../actions'
import { connect } from 'react-redux';
import {action} from "../../store";
import './book-tile.scss'
import {Route} from "react-router";

interface MyState {
    // books: string
}
interface Book {
    title : string,
    id: number
}
interface MyProps {
    books: Book[]
}


class BookTile extends React.Component <MyProps, MyState>{
    handleClick(book: Book) {
        action(showBook(book));
        // const history = useHistory();
        // history.push('/cart');
        // history.go(0);
    }
    constructor(props:any) {
        super(props);
        action(fetchBooks());
    }

    render() {
        let { books } = this.props;
        console.log(books);

        return <div className='book-tile'>
            {books && books.length>0 && books.map((book) =>
                <div className='book'>
                    <div className='image'></div>
                <div className='book-title'>{book.title}</div>
                <div className='book-description'>{book.title}</div>
                    <Route render={({ history}) => (
                        <button className='buy-now' onClick={() => {this.buyNow(book, history)}}>Buy Now </button>
                    )} />
            </div>)}
        </div>
    }

    private buyNow(book: Book, history:any) {
        action(showBook(book));
        history.push('/details');
    }
}

const mapStateToProps = (state:any) => ({
     books: state.books
});
const mapDispatchToProps = {
    fetchBooks: fetchBooks,
    addToCart: addToCart,
    showBook: showBook

};
export default connect(mapStateToProps, mapDispatchToProps)(BookTile);
