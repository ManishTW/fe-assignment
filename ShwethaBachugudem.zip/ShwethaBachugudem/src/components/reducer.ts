
interface Book {
    title : string,
    id: number
}

const reducer = (state = {cart: [] as any, currentBook: {id:'', title: ''}, boughtBooks: [] as any}, action: any) => {
    switch (action.type) {
        case 'GET_BOOK_DETAILS':
            return { ...state, loading: true };
        case 'FETCH_BOOKS':
            return { ...state, loading: true };
        case 'BOOKS':
            return { ...state, books: action.json, loading: false};
        case 'ADD_TO_CART':
            return  { ...state, cart:  state.cart.concat(action.book)};
        case 'SHOW_BOOK':
            return  { ...state, currentBook: action.book};
        case 'BUY_BOOK' :
            return { ...state, boughtBooks: state.boughtBooks.concat(state.cart), cart: []};
        default:
            return state;
    }
};
export default reducer;

