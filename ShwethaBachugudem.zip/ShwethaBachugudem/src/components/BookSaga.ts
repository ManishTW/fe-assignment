import { put, takeLatest, all } from 'redux-saga/effects';
function* fetchBooks() {
    const json = yield fetch('https://jsonplaceholder.typicode.com/todos')
        .then(response => response.json(), );
    yield put({ type: "BOOKS", json: json, });
}
function* actionWatcher() {
    yield takeLatest('FETCH_BOOKS', fetchBooks)
}

export default function* rootSaga() {
    yield all([
        actionWatcher(),
    ]);
}
