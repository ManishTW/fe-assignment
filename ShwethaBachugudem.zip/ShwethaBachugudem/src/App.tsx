import React from 'react';
import './App.css';
import BookTile from './components/bookTile/BookTile'

class App extends React.Component{
  render() {
    return <div className= 'books'>
      <BookTile/>
    </div>
  }
}

export default App;
