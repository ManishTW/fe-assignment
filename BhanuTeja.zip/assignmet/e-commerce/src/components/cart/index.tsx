import React, { Component } from 'react';
import { connect} from "react-redux";
import { Book } from '../../store/reducer';
import store from '../../store';
import { Route } from "react-router";
import { buyBooks } from '../../store/actions';
import './styles.css';

interface props {
  cart: Book[]
}

class Cart extends Component<props> {
  state = {
    cartValue: this.calculateCartValue()
  }

  calculateCartValue() {
    return this.props.cart.reduce((price: any, book: any) => {
      return price + book.price;
    }, 0);
  }

  buyBooks(history: any) {
    store.dispatch(buyBooks())
    history.push('/orders')
  }

  render () {
    this.calculateCartValue();
    const { cart } = this.props;

    return <div className="cart">
      <div className="shipping-address">
        <div className="heading">Shipping address</div>
        <textarea className="address" />
        <button className='submit'>Submit</button>
      </div>
      <div className="shopping-bag">
        <div className="heading">Shopping bag</div>
        <div className="cart-details">
          {cart && cart.length > 0 && cart.map((book) => {
            return <div className='bag'>
                <img className="image" src={book.imageUrl} alt="" />
                <div className='cart-title'>{book.name}</div>
            </div>})
          }
        </div>
        <div className='payment-info'>
          <div className="heading">Payment info</div>
            <div className='price'><b>Items Price: </b>{this.state.cartValue}</div>
            <div className='price'><b>Tax: </b>{this.state.cartValue/20}</div>
            <div className='shipping'><b>Shipping charges: </b>{this.state.cartValue/10}</div>
            <div className='total'>
              <b>Total Amount: </b>
              {this.state.cartValue + this.state.cartValue/20 + this.state.cartValue/10}
            </div>
            <Route render={({ history }) => (
                <button className="checkout-button" onClick={() => {this.buyBooks(history)}}>checkout </button>
            )} />
        </div>
      </div>
    </div>
  }
}

const mapStateToProps = (state: any) => ({
  cart: state.cart
});
export default connect(mapStateToProps)(Cart);