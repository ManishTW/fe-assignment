import React, { Component } from 'react';
import {Link} from "react-router-dom";
import './style.css'

class Header extends Component {
  render () {
    return <div className='header'>
        <span className='site'>E-commerce</span>
        <div className='links'>
          <Link className='link' to='/'>Home</Link><b> | </b>
          <Link className='link' to='/orders'>My Orders</Link><b> | </b>
          <Link className='link' to='/cart'>Cart</Link>
        </div>
    </div>
  }
}
export default Header;
