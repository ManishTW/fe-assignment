import React, { Component } from 'react';
import { fetchBooks, viewBook } from '../../store/actions';
import { connect } from 'react-redux';
import store from '../../store';
import { Book } from '../../store/reducer';
import { Route } from 'react-router';
import './styles.css';

interface props {
  books: Book[]
};

class Books extends Component<props> {
  constructor(props:any) {
    super(props);
    store.dispatch(fetchBooks());
  }

  viewBook(book: Book, history:any) {
    store.dispatch(viewBook(book));
    history.push('/book');
  }

  render () {
    let { books } = this.props;
    return <div className='books'>
    { books && books.length && books.map(book =>
      <div className='book'>
        <img className="book-image" src={book.imageUrl} alt="" />
        <div className='book-title'><b>Title:</b> { book.name }</div>
        <div className='book-description'><b>Destription:</b> { book.name }</div>
        <Route render={({history}) => (
          <button className='view-book' onClick={() => {this.viewBook(book, history)}} > View </button>
        )} />
      </div>)
    }
    </div>
  }
};

const mapStateToProps = (state: any) => ({
  books: state.books
});
const mapDispatchToProps = {
  fetchBooks: fetchBooks
};
export default connect(mapStateToProps, mapDispatchToProps)(Books);
