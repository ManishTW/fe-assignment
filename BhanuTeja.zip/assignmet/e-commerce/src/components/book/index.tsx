import React, { Component } from 'react';
import { connect } from 'react-redux';
import { addToCart, buyBook } from '../../store/actions';
import { Book } from '../../store/reducer'
import store from '../../store';
import { Route } from 'react-router';
import './styles.css';

interface props {
  book: Book
};

class BookDetails extends Component<props> {

  addCart(book: Book, history:any) {
    store.dispatch(addToCart(book));
    history.push('/cart');
  }

  buyBooks(book: Book, history:any) {
    store.dispatch(buyBook(book));
    history.push('/orders');
  }

  render () {
    const { book } = this.props;
    return <div className='book-details'>
        <div className="book-image">
          <img src={book.imageUrl} alt="" />
        </div>
        <div className='book-info'>
          <div className='details'>
            <div className='title'><b>Title: </b>{ book.name }</div>
            <div className='author'><b>Author: </b>{ book.author }</div>
            <div className='description'><b>Description: </b>{ book.name }</div>
            <div className='price'><b>Price: </b>{ book.price }</div>
            <Route render={({ history }) => (
                <button className='add-to-cart' onClick={() => this.addCart(book, history)}>Add to Cart</button>
            )} />
            <Route render={({ history }) => (
                <button className='buy-now' onClick={() => this.buyBooks(book, history)}>Buy Now</button>
            )} />
          </div>
        </div>
    </div>
  }
};

const mapStateToProps = (state:any) => ({
  book: state.book
});
const mapDispatchToProps = {
  addToCart: addToCart
};
export default connect(mapStateToProps, mapDispatchToProps)(BookDetails);