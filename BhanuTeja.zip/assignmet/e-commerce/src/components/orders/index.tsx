import React, { Component } from 'react';
import { connect } from "react-redux";
import { Book } from '../../store/reducer'
import './styles.css';

interface props {
  books: Book[]
}
class Orders extends Component<props> {
  render () {
    const { books } = this.props;
    return<div className='purchased-book'> 
      {books && books.length > 0 && books.map(book => {
        return <div className="single-book">
          <img className="book-image" src={book.imageUrl} alt="" />
          <div className='info'>
            <div className='book-title'><b>Name: </b>{ book.name }</div>
            <div className='book-author'><b>Author: </b>{ book.author }</div>
            <div className='book-description'><b>Price: </b>{ book.price }</div>
          </div>
        </div>
        })
      }
    </div>
  }
}

const mapStateToProps = (state:any) => ({
  books: state.orders
});
export default connect(mapStateToProps)(Orders);