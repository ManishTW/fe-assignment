import React, { Component } from 'react';
import './App.css';
import { BrowserRouter as Router, Route, Switch } from 'react-router-dom';
import Books from './books';
import BookDetails from './book';
import Cart from './cart';
import Orders from './orders';
import Header from './header';

class App extends Component {
  render() {
    return (
      <Router>
        <Header />
        <Switch>
          <Route exact path="/" component={Books} />
          <Route exact path="/book" component={BookDetails} />
          <Route exact path="/cart" component={Cart} />
          <Route exact path="/orders" component={Orders} />
        </Switch>
      </Router>
    );
  }
}

export default App;
