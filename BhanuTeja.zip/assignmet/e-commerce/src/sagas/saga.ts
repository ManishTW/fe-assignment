import { takeLatest, put } from 'redux-saga/effects';
import { FETCH_BOOKS, SHOW_BOOKS } from '../store/actionTypes';

function* fetchBooks() {
  const response = yield fetch('http://localhost:8080/books')
                          .then(response => response.json());
  yield put({ type: SHOW_BOOKS, books: response });
}

export function* watchFetchBooks() {
  yield takeLatest(FETCH_BOOKS, fetchBooks);
}
