export const FETCH_BOOKS = "FETCH_BOOKS";
export const SHOW_BOOKS = "SHOW_BOOKS";
export const VIEW_BOOK = "VIEW_BOOK";
export const BUY_BOOK = "BUY_BOOK";
export const ADD_TO_CART = "ADD_TO_CART";
export const BUY_BOOKS = "BUY_BOOKS";