import { FETCH_BOOKS, SHOW_BOOKS, VIEW_BOOK, BUY_BOOK, ADD_TO_CART, BUY_BOOKS } from './actionTypes';

export interface Book {
    id: number,
    name: string,
    price: number,
    currency: string,
    author: string,
    imageUrl: string,
    isAvailable: boolean
}

const initialState = {
  book: {} as Book,
  books: [] as Array<Book>,
  cart: [] as Array<Book>,
  orders: [] as Array<Book>
};

const reducer = (state = initialState, action: any) => {
  switch(action.type) {
    case FETCH_BOOKS:
      return { ...state };
    case SHOW_BOOKS:
      return { ...state, books: action.books };
    case VIEW_BOOK:
      return { ...state, book: action.book };
    case BUY_BOOK:
      return { ...state, orders: state.orders.concat(action.book)};
    case ADD_TO_CART:
      return { ...state, cart: state.cart.concat(action.book)};
    case BUY_BOOKS :
      return { ...state, orders: state.orders.concat(state.cart), cart: []};
    default:
      return state;
  }
}

export default reducer;