import { createStore, applyMiddleware } from 'redux';
import reducer from  './reducer';
import createSageMiddleWare from 'redux-saga';
import { watchFetchBooks } from '../sagas/saga';

const sagaMiddleware = createSageMiddleWare();
const store = createStore(reducer, applyMiddleware(sagaMiddleware));
sagaMiddleware.run(watchFetchBooks);

export default store;
