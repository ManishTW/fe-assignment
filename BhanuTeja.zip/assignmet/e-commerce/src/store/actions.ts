import { FETCH_BOOKS, VIEW_BOOK, BUY_BOOK, ADD_TO_CART, BUY_BOOKS } from './actionTypes';
import { Book } from './reducer';

export const fetchBooks = () => ({ type: FETCH_BOOKS });
export const viewBook = (book: Book ) => ({ type: VIEW_BOOK, book });
export const buyBook = (book: Book) => ({ type: BUY_BOOK, book })
export const addToCart = (book: Book) => ({ type: ADD_TO_CART, book });
export const buyBooks = () => ({ type: BUY_BOOKS });
