import React from 'react';
import { DropdownHook as useDropdownHook } from './DropdownHook';

const Dropdown = ({ values }) => {
	const { addProductQuantity } = useDropdownHook();

	return (
		<select onChange={e => addProductQuantity(Number(e.target.value))} style={dropdownStyle}>
			{
				values.map(value => {
					return <option value={value}>{value}</option>;
				})
			}
		</select>
	);
}

const dropdownStyle = {
	width: "100px",
	height: "25px",
	"margin-right": "20px"
};

export { Dropdown };