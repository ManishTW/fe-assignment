import React, { useEffect } from 'react';
import { Dropdown } from './Dropdown';
import { CartHook as useCartHook } from './CartHook';
import { DropdownHook as useDropdownHook } from './DropdownHook';

const AddToCart = ({ productsPerPerson, productId }) => {
	const { addProduct } = useCartHook();
	const { productQuantity } = useDropdownHook();

	const addToCartHandler = () => {
		addProduct(productId, productQuantity, productsPerPerson);
	}

	return (
		<div className="add-to-cart">
			<Dropdown values={productsPerPerson} />
			<button onClick={addToCartHandler} style={buttonStyle}>Add to cart</button>
		</div>
	)
}

const buttonStyle = {
  width: "150px",
  height: "25px",
  "font-weight": "bold"
};

export { AddToCart };