import { useState } from 'react';

const CartHook = () => {
	const [products, setProducts] = useState([]);

	const addToCart = (id, quantity) => {
		let newProduct = { id, quantity }
		const xproducts = products.filter(element => element.id != id);
		xproducts.push(newProduct);

		setProducts(xproducts);
	};

	 const isEmptyCart = () => {
		 return products.length === 0;
	 }

	 const addProductsToCart = (productId, quantity, productsPerPerson) => {
		products.filter(product => {
			if(product.id === productId) {
				let newProductQuantity = product.quantity + quantity;
				if(newProductQuantity < productsPerPerson) {
					addToCart(productId, newProductQuantity);
				} else {
					addToCart(productId, productsPerPerson);
				}
			}	else {
				addToCart(productId, quantity);
			}
		});
	 }
	
  const addProduct = (productId, quantity, productsPerPerson) => {

		if(isEmptyCart()) {
			addToCart(productId, quantity);
		} else {
			addProductsToCart(productId, quantity, productsPerPerson);
		}
	};

  return {
    products,
		addProduct
  };
};

export { CartHook };
