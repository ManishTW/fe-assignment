import { useState, useEffect } from 'react';

const DropdownHook = () => {
  const [productQuantity, setProductQuantity] = useState(0);
  
  const addProductQuantity = (productQuantity) => {
    setProductQuantity(productQuantity);
  }

  useEffect(() => {
    console.log(productQuantity);
  }, [productQuantity]);

  return {
		productQuantity,
    addProductQuantity
  };
};

export { DropdownHook };
