import React from 'react';

const Cart = () => {
	return <div>hello</div>;
}

export { Cart };