import React from 'react';
import { Products } from './components/Products'
import './App.css';


function App() {
  return (
    <div className="App">
      <Products />
    </div>
  );
}

export default App;
