# Follow the below instructions to start the application
### Checkout to e-commerce-backend and run the command `node server.js`
### Then checkout to e-commerce and run the following commands 1) `npm install` and 2) `npm run start`